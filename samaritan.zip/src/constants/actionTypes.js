export const FEATURE_CLICKED = 'samaritan/map/featureClicked';
export const DATA_REQUEST = 'samaritan/map/dataRequest';
export const DATA_SUCCESS = 'samaritan/map/dataSuccess';
export const DATA_FAIL = 'samaritan/map/dataFail';
export const LAYER_SWITCH = 'samaritan/map/layerSwitch';
export const SET_TIME_FILTER = 'samaritan/map/setTimeFilter';
